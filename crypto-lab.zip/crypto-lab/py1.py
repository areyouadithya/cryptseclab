import torch
import torch.nn as nn
import torchvision.models as models

# Load a pre-trained 3D ResNet model (ResNet-18 as an example)
model = models.video.r3d_18(pretrained=True)

# Save the number of input features to the fully connected layer before replacing it
in_features = model.fc.in_features

# Modify the final layer to output features instead of class probabilities
model.fc = nn.Identity()  # Replace the final fully connected layer with an identity function

# Example input: a batch of 2 video clips, each with 16 frames, with each frame being 3x112x112 in size
# The shape of the input tensor should be [batch_size, channels, depth, height, width]
example_input = torch.rand(2, 3, 16, 112, 112)

# Pass the input through the model to extract features
features = model(example_input)

# Output the shape of the extracted features
print("Extracted features shape:", features.shape)  # Expected output: torch.Size([2, 512])

# If you want to fine-tune the model or use it for classification,
# replace the identity function with a new fully connected layer
num_classes = 2  # For binary classification (e.g., Real/Fake)
model.fc = nn.Linear(in_features, num_classes)

# Example of passing the input through the entire model (including the new classification layer)
output = model(example_input)

# Output the shape of the final classification output
print("Classification output shape:", output.shape)  # Expected output: torch.Size([2, 2])
