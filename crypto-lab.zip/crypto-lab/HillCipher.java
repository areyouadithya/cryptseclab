import java.util.Scanner;

public class HillCipher {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Size of the key matrix
        int n;
        
        System.out.print("Enter the size of the key matrix: ");
        n = sc.nextInt();
        
        int[][] keyMatrix = new int[n][n];
        
        System.out.println("Enter the key matrix (row-wise): ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                keyMatrix[i][j] = sc.nextInt();
            }
        }
        
        System.out.print("Enter the plaintext: ");
        sc.nextLine(); // consume newline left-over
        String plaintext = sc.nextLine().toUpperCase();
        
        // Pad plaintext if necessary
        int padding = n - (plaintext.length() % n);
        if (padding != n) {
            for (int i = 0; i < padding; i++) {
                plaintext += 'X';
            }
        }
        
        System.out.println("Ciphertext: " + encrypt(plaintext, keyMatrix, n));
    }
    
    public static String encrypt(String plaintext, int[][] keyMatrix, int n) {
        StringBuilder ciphertext = new StringBuilder();
        int[] tempVector = new int[n];
        
        for (int i = 0; i < plaintext.length(); i += n) {
            for (int j = 0; j < n; j++) {
                tempVector[j] = plaintext.charAt(i + j) - 'A';
            }
            
            int[] encryptedVector = multiply(keyMatrix, tempVector, n);
            
            for (int j = 0; j < n; j++) {
                ciphertext.append((char) (encryptedVector[j] % 26 + 'A'));
            }
        }
        
        return ciphertext.toString();
    }
    
    public static int[] multiply(int[][] keyMatrix, int[] vector, int n) {
        int[] result = new int[n];
        
        for (int i = 0; i < n; i++) {
            result[i] = 0;
            for (int j = 0; j < n; j++) {
                result[i] += keyMatrix[i][j] * vector[j];
            }
        }
        
        return result;
    }
}
