import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class EncryptionClient {

    public static void main(String[] args) {
        String serverAddress = "localhost";  // Server address
        int port = 12345;  // Port number

        try (Socket socket = new Socket(serverAddress, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner sc = new Scanner(System.in)) {

            System.out.println("Enter command (1.encrypt, 2.decrypt, 3.mencrypt, 4.mdecrypt, 5.affineEncrypt, 6.affineDecrypt): ");
            int command = Integer.parseInt(sc.nextLine());
            System.out.println("Enter text: ");
            String text = sc.nextLine();

            int key1, key2;

            if (command == 5 || command == 6) { // For affine encryption and decryption
                System.out.println("Enter key1: ");
                key1 = Integer.parseInt(sc.nextLine());
                System.out.println("Enter key2: ");
                key2 = Integer.parseInt(sc.nextLine());

                out.println(command);
                out.println(text);
                out.println(key1);
                out.println(key2);
            } else { // For other encryption methods
                System.out.println("Enter key: ");
                key1 = Integer.parseInt(sc.nextLine());

                out.println(command);
                out.println(text);
                out.println(key1);
                out.println(0); // Placeholder for key2
            }

            String response = in.readLine();
            System.out.println("Server response: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
