import random

# Modular exponentiation
def mod_exp(base, exp, mod):
    """Perform modular exponentiation (base^exp) % mod efficiently."""
    result = 1
    while exp > 0:
        if exp % 2 == 1:
            result = (result * base) % mod
        base = (base * base) % mod
        exp //= 2
    return result

# Euclidean algorithm to find the greatest common divisor
def gcd(a, b):
    """Compute the greatest common divisor using Euclidean algorithm."""
    while b != 0:
        a, b = b, a % b
    return a

# Key generation function
def generate_keys(p):
    """Generate ElGamal public and private keys."""
    g = random.randint(2, p - 1)  # Choose a random generator
    x = random.randint(1, p - 2)  # Private key (x)
    h = mod_exp(g, x, p)          # Public key component (g^x % p)
    return (p, g, h), x           # Return (public key, private key)

# ElGamal encryption
def encrypt(public_key, plaintext):
    """Encrypt the plaintext using the public key."""
    p, g, h = public_key
    y = random.randint(1, p - 2)  # Random integer (ephemeral key)
    c1 = mod_exp(g, y, p)         # c1 = g^y % p
    s = mod_exp(h, y, p)          # s = (g^x)^y % p (shared secret)
    c2 = (plaintext * s) % p      # c2 = plaintext * shared secret % p
    return c1, c2

# ElGamal decryption
def decrypt(private_key, p, c1, c2):
    """Decrypt the ciphertext using the private key."""
    s = mod_exp(c1, private_key, p)   # s = (g^y)^x % p (shared secret)
    s_inv = mod_exp(s, p - 2, p)      # Multiplicative inverse of s modulo p
    plaintext = (c2 * s_inv) % p  # plaintext = (c2 * s_inv) % p
    return plaintext

# Example usage:

# Prime number p (you should use a large prime in practice)
p = 467

# Generate public and private keys
public_key, private_key = generate_keys(p)
print("Public Key:", public_key)
print("Private Key:", private_key)

# Plaintext (an integer in the range 1 to p-1)
plaintext = 123
print("Original Plaintext:", plaintext)

# Encrypt the plaintext
ciphertext = encrypt(public_key, plaintext)
print("Ciphertext:", ciphertext)

# Decrypt the ciphertext
decrypted_text = decrypt(private_key, public_key[0], ciphertext[0], ciphertext[1])
print("Decrypted Text:", decrypted_text)


