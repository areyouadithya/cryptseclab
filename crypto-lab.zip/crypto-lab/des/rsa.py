def ksa(key):
    """Key-Scheduling Algorithm (KSA)"""
    key_length = len(key)

    # Initialize the permutation in the array "S"
    S = list(range(256))

    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % key_length]) % 256
        S[i], S[j] = S[j], S[i]  # Swap values

    return S

def prga(S):
    """Pseudo-Random Generation Algorithm (PRGA)"""
    i = 0
    j = 0
    while True:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]  # Swap values
        K = S[(S[i] + S[j]) % 256]
        yield K

def rc4(key, plaintext):
    """RC4 encryption/decryption"""
    # Convert the key into a list of integer byte values
    key = [ord(c) for c in key]

    # Step 1: KSA to initialize S
    S = ksa(key)

    # Step 2: PRGA to generate the keystream
    keystream = prga(S)

    # Step 3: XOR plaintext with keystream to get the ciphertext
    ciphertext = [chr(ord(c) ^ next(keystream)) for c in plaintext]

    return ''.join(ciphertext)

# Example usage:
key = 'Key'  # Your encryption key
plaintext = 'Hello, World!'  # Your plaintext message

# Encrypt the plaintext
ciphertext = rc4(key, plaintext)
print("Ciphertext:", ciphertext)

# Decrypt the ciphertext (RC4 decryption is symmetric)
decrypted_text = rc4(key, ciphertext)
print("Decrypted text:", decrypted_text)
