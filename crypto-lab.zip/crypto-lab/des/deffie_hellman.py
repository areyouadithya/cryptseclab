import random

# Modular exponentiation (for large numbers)
def mod_exp(base, exp, mod):
    """Perform modular exponentiation (base^exp) % mod efficiently."""
    result = 1
    while exp > 0:
        if exp % 2 == 1:
            result = (result * base) % mod
        base = (base * base) % mod
        exp //= 2
    return result

# Key generation for Diffie-Hellman
def diffie_hellman_key_exchange(p, g):
    """Generate private and public keys for Diffie-Hellman."""
    # Private key (random integer between 1 and p-2)
    private_key = random.randint(1, p - 2)
    
    # Public key = g^private_key % p
    public_key = mod_exp(g, private_key, p)
    
    return private_key, public_key

# Shared secret computation
def compute_shared_secret(their_public_key, your_private_key, p):
    """Compute the shared secret using the other party's public key and your private key."""
    # Shared secret = their_public_key^your_private_key % p
    shared_secret = mod_exp(their_public_key, your_private_key, p)
    
    return shared_secret

# Example usage:

# Prime number p and generator g (agreed upon by both parties)
p = 23  # This is a small prime, but in practice, a very large prime is used
g = 5   # A small generator for demonstration

# Party 1 generates their private and public keys
private_key1, public_key1 = diffie_hellman_key_exchange(p, g)
print("Party 1 Private Key:", private_key1)
print("Party 1 Public Key:", public_key1)

# Party 2 generates their private and public keys
private_key2, public_key2 = diffie_hellman_key_exchange(p, g)
print("Party 2 Private Key:", private_key2)
print("Party 2 Public Key:", public_key2)

# Both parties exchange public keys and compute the shared secret
shared_secret1 = compute_shared_secret(public_key2, private_key1, p)
shared_secret2 = compute_shared_secret(public_key1, private_key2, p)

print("Party 1 Shared Secret:", shared_secret1)
print("Party 2 Shared Secret:", shared_secret2)

# The shared secret should be the same for both parties
assert shared_secret1 == shared_secret2, "Shared secrets do not match!"
