import java.math.BigInteger;

public class EulersTheorem {

    // Method to compute the Euler's Totient Function φ(n)
    public static int eulerTotient(int n) {
        int result = n;

        for (int p = 2; p * p <= n; p++) {
            if (n % p == 0) {
                while (n % p == 0) {
                    n /= p;
                }
                result -= result / p;
            }
        }

        // If n is a prime number greater than 1
        if (n > 1) {
            result -= result / n;
        }

        return result;
    }

    // Method to compute a^b % n using modular exponentiation
    public static BigInteger modularExponentiation(BigInteger a, BigInteger b, BigInteger n) {
        BigInteger result = BigInteger.ONE;
        a = a.mod(n);

        while (b.compareTo(BigInteger.ZERO) > 0) {
            if (b.mod(BigInteger.TWO).equals(BigInteger.ONE)) {
                result = result.multiply(a).mod(n);
            }
            a = a.multiply(a).mod(n);
            b = b.divide(BigInteger.TWO);
        }

        return result;
    }

    // Method to apply Euler's Theorem
    public static BigInteger eulersTheorem(BigInteger a, int n) {
        int phiN = eulerTotient(n);
        return modularExponentiation(a, BigInteger.valueOf(phiN), BigInteger.valueOf(n));
    }

    public static void main(String[] args) {
        BigInteger a = new BigInteger("7");
        int n = 40;

        BigInteger result = eulersTheorem(a, n);
        System.out.println("According to Euler's Theorem: " + a + "^φ(" + n + ") ≡ " + result + " (mod " + n + ")");
    }
}