public class ExtendedEuclideanAlgorithm {

    public static int[] extendedEuclidean(int a, int b) {
        if (b == 0) {
            return new int[]{a, 1, 0};  // GCD is 'a', x is 1, y is 0
        }
        
        int[] result = extendedEuclidean(b, a % b);
        int gcd = result[0];
        int x = result[2];
        int y = result[1] - (a / b) * result[2];

        return new int[]{gcd, x, y};
    }

    public static void main(String[] args) {
        int a = 30, b = 20;
        int[] result = extendedEuclidean(a, b);
        
        System.out.println("GCD: " + result[0]);
        System.out.println("x: " + result[1]);
        System.out.println("y: " + result[2]);
    }
}
