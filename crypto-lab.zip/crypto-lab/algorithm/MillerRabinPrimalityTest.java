import java.math.BigInteger;
import java.security.SecureRandom;

public class MillerRabinPrimalityTest {

    // Method to perform the Miller-Rabin test
    public static boolean isProbablePrime(BigInteger n, int k) {
        // Handle simple cases
        if (n.equals(BigInteger.TWO) || n.equals(BigInteger.valueOf(3))) {
            return true;
        }
        if (n.compareTo(BigInteger.TWO) < 0 || n.mod(BigInteger.TWO).equals(BigInteger.ZERO)) {
            return false;
        }

        // Write n as d * 2^r + 1
        BigInteger d = n.subtract(BigInteger.ONE);
        int r = 0;
        while (d.mod(BigInteger.TWO).equals(BigInteger.ZERO)) {
            d = d.divide(BigInteger.TWO);
            r++;
        }

        SecureRandom random = new SecureRandom();
        for (int i = 0; i < k; i++) {
            BigInteger a = uniformRandom(BigInteger.TWO, n.subtract(BigInteger.ONE), random);
            BigInteger x = a.modPow(d, n);

            if (x.equals(BigInteger.ONE) || x.equals(n.subtract(BigInteger.ONE))) {
                continue;
            }

            boolean continueLoop = false;
            for (int j = 0; j < r - 1; j++) {
                x = x.modPow(BigInteger.TWO, n);
                if (x.equals(BigInteger.ONE)) {
                    return false;
                }
                if (x.equals(n.subtract(BigInteger.ONE))) {
                    continueLoop = true;
                    break;
                }
            }

            if (!continueLoop) {
                return false;
            }
        }

        return true; // n is probably prime
    }

    // Helper method to generate a random BigInteger in the range [min, max]
    private static BigInteger uniformRandom(BigInteger min, BigInteger max, SecureRandom random) {
        BigInteger result;
        do {
            result = new BigInteger(max.bitLength(), random);
        } while (result.compareTo(min) < 0 || result.compareTo(max) > 0);
        return result;
    }

    public static void main(String[] args) {
        BigInteger n = new BigInteger("561");  // Carmichael number, which is a composite number
        int k = 5;  // Number of iterations (higher k -> higher accuracy)

        if (isProbablePrime(n, k)) {
            System.out.println(n + " is probably prime.");
        } else {
            System.out.println(n + " is composite.");
        }
    }
}
