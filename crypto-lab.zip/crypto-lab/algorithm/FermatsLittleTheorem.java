public class FermatsLittleTheorem {

    // Method to check if a number is prime
    public static boolean isPrime(int p) {
        if (p <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(p); i++) {
            if (p % i == 0) {
                return false;
            }
        }
        return true;
    }

    // Method to apply Fermat's Little Theorem
    public static boolean fermatsLittleTheorem(int a, int p) {
        if (p <= 1) {
            throw new IllegalArgumentException("p must be a prime number greater than 1");
        }
        if (!isPrime(p)) {
            throw new IllegalArgumentException("p must be a prime number");
        }

        // Calculate a^(p-1) % p using modular exponentiation
        int result = 1;
        int base = a % p;
        int exponent = p - 1;

        while (exponent > 0) {
            if ((exponent & 1) == 1) {  // If exponent is odd
                result = (result * base) % p;
            }
            base = (base * base) % p;
            exponent >>= 1;  // Divide exponent by 2
        }

        return result == 1;
    }

    public static void main(String[] args) {
        int a = 2;
        int p = 7;

        boolean result = fermatsLittleTheorem(a, p);
        System.out.println(result);  // Output: true
    }
}
