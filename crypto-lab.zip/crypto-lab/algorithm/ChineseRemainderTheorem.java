import java.util.Arrays;

public class ChineseRemainderTheorem {

    // Helper class to store the result (gcd, x, y)
    public static class Result {
        public int gcd;
        public int x;
        public int y;

        public Result(int gcd, int x, int y) {
            this.gcd = gcd;
            this.x = x;
            this.y = y;
        }
    }

    // Method to implement the Extended Euclidean Algorithm
    public static Result extendedEuclidean(int a, int b) {
        if (b == 0) {
            return new Result(a, 1, 0);
        } else {
            Result result = extendedEuclidean(b, a % b);
            int gcd = result.gcd;
            int x = result.y;
            int y = result.x - (a / b) * result.y;

            return new Result(gcd, x, y);
        }
    }

    // Method to solve the system of congruences using the Chinese Remainder Theorem
    public static int chineseRemainderTheorem(int[] a, int[] m) {
        int M = 1;
        for (int modulus : m) {
            M *= modulus;
        }

        int x = 0;
        for (int i = 0; i < m.length; i++) {
            int Mi = M / m[i];
            Result result = extendedEuclidean(Mi, m[i]);
            int MiInverse = result.x;

            x = (x + a[i] * Mi * MiInverse) % M;
        }

        // Ensure the solution is positive
        if (x < 0) {
            x += M;
        }

        return x;
    }

    public static void main(String[] args) {
        int[] a = {2, 3, 2};  // Remainders
        int[] m = {3, 5, 7};  // Moduli (must be pairwise coprime)

        int solution = chineseRemainderTheorem(a, m);
        System.out.println("Solution: x ≡ " + solution + " (mod " + Arrays.stream(m).reduce(1, (x, y) -> x * y) + ")");
    }
}
