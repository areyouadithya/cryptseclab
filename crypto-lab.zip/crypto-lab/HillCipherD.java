import java.util.Scanner;

public class HillCipherD {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n;
        System.out.print("Enter the size of the key matrix: ");
        n = sc.nextInt();

        int[][] keyMatrix = new int[n][n];
        System.out.println("Enter the key matrix (row-wise): ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                keyMatrix[i][j] = sc.nextInt();
            }
        }

        System.out.print("Enter the plaintext: ");
        sc.nextLine(); // consume newline left-over
        String plaintext = sc.nextLine().toUpperCase();

        String ciphertext = encrypt(plaintext, keyMatrix, n);
        System.out.println("Ciphertext: " + ciphertext);

        try {
            String decryptedText = decrypt(ciphertext, keyMatrix, n);
            System.out.println("Decrypted Text: " + decryptedText);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static String encrypt(String plaintext, int[][] keyMatrix, int n) {
        StringBuilder ciphertext = new StringBuilder();
        int[] tempVector = new int[n];

        for (int i = 0; i < plaintext.length(); i += n) {
            for (int j = 0; j < n; j++) {
                tempVector[j] = plaintext.charAt(i + j) - 'A';
            }

            int[] encryptedVector = multiply(keyMatrix, tempVector, n);

            for (int j = 0; j < n; j++) {
                ciphertext.append((char) (encryptedVector[j] % 26 + 'A'));
            }
        }

        return ciphertext.toString();
    }

    public static String decrypt(String ciphertext, int[][] keyMatrix, int n) throws ArithmeticException {
        StringBuilder plaintext = new StringBuilder();
        int[][] inverseKeyMatrix = findInverseMatrix(keyMatrix, n);

        int[] tempVector = new int[n];

        for (int i = 0; i < ciphertext.length(); i += n) {
            for (int j = 0; j < n; j++) {
                tempVector[j] = ciphertext.charAt(i + j) - 'A';
            }

            int[] decryptedVector = multiply(inverseKeyMatrix, tempVector, n);

            for (int j = 0; j < n; j++) {
                plaintext.append((char) ((decryptedVector[j] % 26 + 26) % 26 + 'A'));
            }
        }

        return plaintext.toString();
    }

    public static int[] multiply(int[][] matrix, int[] vector, int n) {
        int[] result = new int[n];

        for (int i = 0; i < n; i++) {
            result[i] = 0;
            for (int j = 0; j < n; j++) {
                result[i] += matrix[i][j] * vector[j];
            }
        }

        return result;
    }

    public static int[][] findInverseMatrix(int[][] matrix, int n) throws ArithmeticException {
        int[][] adjoint = new int[n][n];
        int[][] inverse = new int[n][n];
        int determinant = findDeterminant(matrix, n);
        int determinantModInverse = modInverse(determinant, 26);

        if (determinant == 0 || determinantModInverse == -1) {
            throw new ArithmeticException("Key matrix is not invertible.");
        }

        adjoint(matrix, adjoint, n);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                inverse[i][j] = (adjoint[i][j] * determinantModInverse) % 26;
                if (inverse[i][j] < 0) {
                    inverse[i][j] += 26;
                }
            }
        }

        return inverse;
    }

    public static int findDeterminant(int[][] matrix, int n) {
        if (n == 1) {
            return matrix[0][0];
        }

        int determinant = 0;
        int[][] temp = new int[n][n];
        int sign = 1;

        for (int i = 0; i < n; i++) {
            getCofactor(matrix, temp, 0, i, n);
            determinant += sign * matrix[0][i] * findDeterminant(temp, n - 1);
            sign = -sign;
        }

        return determinant % 26;
    }

    public static void getCofactor(int[][] matrix, int[][] temp, int p, int q, int n) {
        int i = 0, j = 0;

        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (row != p && col != q) {
                    temp[i][j++] = matrix[row][col];

                    if (j == n - 1) {
                        j = 0;
                        i++;
                    }
                }
            }
        }
    }

    public static void adjoint(int[][] matrix, int[][] adjoint, int n) {
        if (n == 1) {
            adjoint[0][0] = 1;
            return;
        }

        int sign = 1;
        int[][] temp = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                getCofactor(matrix, temp, i, j, n);

                sign = ((i + j) % 2 == 0) ? 1 : -1;
                adjoint[j][i] = (sign * findDeterminant(temp, n - 1)) % 26;
            }
        }
    }

    public static int modInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return -1;
    }
}
