import java.io.*;
import java.net.*;

public class AdditiveCipherClient {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 12345);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter the ciphertext: ");
        String cipherText = userInput.readLine();
        out.println(cipherText);

        String response;
        while ((response = in.readLine()) != null) {
            System.out.println(response);
        }

        socket.close();
    }
}
