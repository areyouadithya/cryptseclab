import java.io.*;
import java.net.*;

public class AdditiveCipherServer {

    private static final int ALPHABET_SIZE = 26;

    // Method to decrypt a message with a given key
    private static String decrypt(String cipherText, int key) {
        StringBuilder plainText = new StringBuilder();
        for (char c : cipherText.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                char decryptedChar = (char) (((c - base - key + ALPHABET_SIZE) % ALPHABET_SIZE) + base);
                plainText.append(decryptedChar);
            } else {
                plainText.append(c);
            }
        }
        return plainText.toString();
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(12345);
        System.out.println("Server listening on port 12345");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String cipherText = in.readLine();

            StringBuilder result = new StringBuilder();
            for (int key = 0; key < ALPHABET_SIZE; key++) {
                String decrypted = decrypt(cipherText, key);
                result.append(String.format("Key=%d: %s\n", key, decrypted));
            }

            out.println(result.toString());
            clientSocket.close();
        }
    }
}
