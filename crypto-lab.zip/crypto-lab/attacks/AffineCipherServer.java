import java.io.*;
import java.net.*;
import java.util.*;

public class AffineCipherServer {

    private static final int ALPHABET_SIZE = 26;

    // Helper method to find modular inverse
    private static int modInverse(int a, int m) {
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return -1; // Inverse does not exist
    }

    // Method to decrypt a message with given key
    private static String decrypt(String cipherText, int a, int b) {
        int aInverse = modInverse(a, ALPHABET_SIZE);
        if (aInverse == -1) {
            return null;
        }

        StringBuilder plainText = new StringBuilder();
        for (char c : cipherText.toCharArray()) {
            if (Character.isLetter(c)) {
                int y = (Character.toUpperCase(c) - 'A');
                int x = (aInverse * (y - b + ALPHABET_SIZE)) % ALPHABET_SIZE;
                if (x < 0) x += ALPHABET_SIZE;
                plainText.append((char) (x + 'A'));
            } else {
                plainText.append(c);
            }
        }
        return plainText.toString();
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(12345);
        System.out.println("Server listening on port 12345");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String cipherText = in.readLine();

            StringBuilder result = new StringBuilder();
            for (int a = 1; a < ALPHABET_SIZE; a++) {
                if (gcd(a, ALPHABET_SIZE) == 1) {
                    for (int b = 0; b < ALPHABET_SIZE; b++) {
                        String decrypted = decrypt(cipherText, a, b);
                        if (decrypted != null) {
                            result.append(String.format("a=%d, b=%d: %s\n", a, b, decrypted));
                        }
                    }
                }
            }

            out.println(result.toString());
            clientSocket.close();
        }
    }

    // Helper method to compute greatest common divisor
    private static int gcd(int a, int b) {
        if (b == 0) return a;
        return gcd(b, a % b);
    }
}
