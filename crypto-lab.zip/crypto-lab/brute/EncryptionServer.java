import java.io.*;
import java.net.*;

public class EncryptionServer {

    public static void main(String[] args) {
        int port = 12345;  // Port number for the server
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            while (true) {
                try (Socket socket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                     PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                    System.out.println("Client connected");

                    int command = Integer.parseInt(in.readLine());
                    String text = in.readLine();
                    int key1 = Integer.parseInt(in.readLine());
                    int key2 = Integer.parseInt(in.readLine());

                    System.out.println("Received command: " + command);
                    System.out.println("Received text: " + text);
                    System.out.println("Received key1: " + key1);
                    System.out.println("Received key2: " + key2);

                    String result;
                    switch (command) {
                        case 1:
                            result = EncryptionUtils.encrypt(text, key1);
                            break;
                        case 2:
                            result = EncryptionUtils.decrypt(text, key1);
                            break;
                        case 3:
                            result = EncryptionUtils.mencrypt(text, key1);
                            break;
                        case 4:
                            result = EncryptionUtils.mdecrypt(text, key1);
                            break;
                        case 5:
                            result = EncryptionUtils.affineEncrypt(text, key1, key2);
                            break;
                        case 6:
                            result = EncryptionUtils.affineDecrypt(text, key1, key2);
                            break;
                        default:
                            result = "Invalid command";
                    }

                    System.out.println("Sending result: " + result);
                    out.println(result);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class EncryptionUtils {

    public static String encrypt(String text, int key) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                encrypted.append((char) (((c - 'A' + key) % 26 + 26) % 26 + 'A'));
            } else if (Character.isLowerCase(c)) {
                encrypted.append((char) (((c - 'a' + key) % 26 + 26) % 26 + 'a'));
            } else if (Character.isDigit(c)) {
                encrypted.append((char) (((c - '0' + key) % 10 + 10) % 10 + '0'));
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }

    public static String decrypt(String text, int key) {
        return encrypt(text, -key);
    }

    public static String mencrypt(String text, int key) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                encrypted.append((char) (((c - 'A') * key % 26 + 26) % 26 + 'A'));
            } else if (Character.isLowerCase(c)) {
                encrypted.append((char) (((c - 'a') * key % 26 + 26) % 26 + 'a'));
            } else if (Character.isDigit(c)) {
                encrypted.append((char) (((c - '0') * key % 10 + 10) % 10 + '0'));
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }

    public static String mdecrypt(String text, int key) {
        int num = key;
        int mod1 = 26, mod2 = 10;
        int inv1 = -1, inv2 = -1;
        for (int i = 1; i < mod1; i++) {
            if ((num * i) % mod1 == 1) {
                inv1 = i;
                break;
            }
        }
        if (inv1 == -1) {
            throw new IllegalArgumentException("No modular inverse found for key: " + key);
        }
        for (int i = 1; i < mod2; i++) {
            if ((num * i) % mod2 == 1) {
                inv2 = i;
                break;
            }
        }
        if (inv2 == -1) {
            throw new IllegalArgumentException("No modular inverse found for key: " + key);
        }
        StringBuilder decrypted = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                decrypted.append((char) (((c - 'A') * inv1 % 26 + 26) % 26 + 'A'));
            } else if (Character.isLowerCase(c)) {
                decrypted.append((char) (((c - 'a') * inv1 % 26 + 26) % 26 + 'a'));
            } else if (Character.isDigit(c)) {
                decrypted.append((char) (((c - '0') * inv2 % 10 + 10) % 10 + '0'));
            } else {
                decrypted.append(c);
            }
        }
        return decrypted.toString();
    }

    public static String affineEncrypt(String text, int a, int b) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                encrypted.append((char) ((a * (c - 'A') + b) % 26 + 'A'));
            } else if (Character.isLowerCase(c)) {
                encrypted.append((char) ((a * (c - 'a') + b) % 26 + 'a'));
            } else if (Character.isDigit(c)) {
                encrypted.append((char) ((a * (c - '0') + b) % 10 + '0'));
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }

    public static String affineDecrypt(String text, int a, int b) {
        int mod1 = 26;
        int mod2 = 10;
        int aInv = modInverse(a, mod1);

        if (aInv == -1) {
            System.out.println("No modular inverse found for a: " + a);
            throw new IllegalArgumentException("No modular inverse found for a: " + a);
        }

        System.out.println("Modular inverse of " + a + " is " + aInv);

        StringBuilder decrypted = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                decrypted.append((char) ((aInv * ((c - 'A') - b + mod1)) % mod1 + 'A'));
            } else if (Character.isLowerCase(c)) {
                decrypted.append((char) ((aInv * ((c - 'a') - b + mod1)) % mod1 + 'a'));
            } else if (Character.isDigit(c)) {
                decrypted.append((char) ((aInv * ((c - '0') - b + mod2)) % mod2 + '0'));
            } else {
                decrypted.append(c);
            }
        }
        return decrypted.toString();
    }

    private static int modInverse(int a, int m) {
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return -1; // No modular inverse exists
    }
}
