import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class CaesarBruteForceAttack {

    public static void main(String[] args) {
        String serverAddress = "localhost";  // Server address
        int port = 12345;  // Port number

        try (Scanner sc = new Scanner(System.in)) {

            System.out.println("Enter the encrypted text: ");
            String encryptedText = sc.nextLine();

            System.out.println("Brute forcing Caesar Cipher...");
            for (int key = 1; key < 26; key++) {
                try (Socket socket = new Socket(serverAddress, port);
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                     PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                    System.out.println("Sending request for key " + key);
                    out.println(2); // Command for decrypt
                    out.println(encryptedText);
                    out.println(key);
                    out.println(0); // Placeholder for key2

                    String response = in.readLine();
                    System.out.println("Key " + key + ": " + response);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                // Add a small delay between attempts
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
